// Project includes
#include "globals.h"
#include "hardware.h"
#include "map.h"
#include "graphics.h"
#include "speech.h"
#include <string>

#include <math.h>
#include<stdio.h>

// Helper function declarations
void playSound(char* wav);

int mode = 0;
void* data = NULL;
void* hold = NULL;
int end1 = 3;
int end2 = 3;

// Top down camera view
struct {
    int x,y;    // Current locations
    int px, py; // Previous locations
} Camera;

//Weapons struct
struct Weapon{
    int dmg; //adds dmg to char dmg
    int range; //adds attack range to char range
    string name; 
};

//Defines each chracter in the game
struct Player{     
    int x,y;    // Current locations
    int hp, def, dmg, range; //stats
    int skill, avoid; //advanced feature stats
    int healing; //number of healing items (each healing item heals 10 health)
    struct Weapon wep; 
};

//types of weapons in game   (Tried doing weapons but got stuck)
struct Weapon spear = {2, 1, "Spear"};
struct Weapon bow = {1, 2, "Bow"};
struct Weapon dagger = {5, 0, "Dagger"};
struct Weapon none = {0, 0, "None"};

//adding 3 characters for each Player
struct Player char1 = {10, 25, 100, 5, 10, 10, 100, 50, 2, 2, 1, "Spear"};  //shown as red boxes
struct Player char2 = {10, 28, 100, 0, 25, 10, 100, 68, 2, 1, 2, "Bow"};
struct Player char3 = {10, 31, 100, 13, 50, 10, 100, 0, 2, 1, 2, "Bow"};
struct Player enemy1 = {50, 25, 1, 20, 30, 3, 100, 0, 0, 0, 0, "None"};   //shown as green
struct Player enemy2 = {50, 28, 1, 3, 15, 3, 100, 0, 0, 0, 0, "None"};
struct Player enemy3 = {50, 31, 1, 7, 75, 3, 200, 0, 0, 0, 0, "Sword"};


/**
 * Given the game inputs, determine what kind of update needs to happen.
 * Possbile return values are defined below.
 */
#define NO_ACTION 0
#define ACTION_BUTTON 1
#define BACK_BUTTON 2
#define GO_LEFT 3
#define GO_RIGHT 4
#define GO_UP 5
#define GO_DOWN 6
#define DISPLAY_BUTTON 7

int get_action(GameInputs inputs)
{
    if (inputs.b1 == 0)
    {
         return ACTION_BUTTON;
    }
    else if (inputs.b2 == 0)
    {
         return BACK_BUTTON;
    }
    else if (inputs.b3 == 0)
    {
        return DISPLAY_BUTTON;
    }
    else if (abs(inputs.ax) > abs(inputs.ay))
    {
        if(inputs.ax > -0.3)
        {
            return GO_RIGHT;
        }
        else if(inputs.ax < 0.3)
        {
            return GO_LEFT;
        }
    }
    else if (abs(inputs.ay) > abs(inputs.ax))
    {
        if(inputs.ay < -0.3)
        {
            return GO_UP;
        }
        else if(inputs.ay > 0.3)
        {
            return GO_DOWN;
        }
    }
    return NO_ACTION;
}


/**
 * Update the game state based on the user action. For example, if the user
 * requests GO_UP, then this function should determine if that is possible by
 * consulting the map, and update the Player position accordingly.
 *
 * Return values are defined below. FULL_DRAW indicates that for this frame,
 * draw_game should not optimize drawing and should draw every tile, even if
 * the player has not moved.
 */
#define NO_RESULT 0
#define GAME_OVER 1
#define FULL_DRAW 2

#define MODE_FREE_ROAM 0
#define MODE_SELECTED 1
int update_game(int action)
{
    // Save player previous location before updating
    Camera.px = Camera.x;
    Camera.py = Camera.y;

    // Do different things based on the action
    // You can define smaller functions that get called for each case
    switch(action) {
        case ACTION_BUTTON:
            if (mode == 0)//free mode for Player 1
            {
                data = NULL;
                if (get_here(Camera.px, Camera.py)->type == CHARACTERSPRITE)
                {
                    mode = 1; //becomes character1 selected mode
                    data = get_here(Camera.px, Camera.py)->data;
                    //uLCD.text_string("C", 4, 4, FONT_7X8, WHITE);
                }
            }
            else if (mode == 3)//free mode for Player 2
            {
                data = NULL;
                if(get_here(Camera.px, Camera.py)->type == ENEMY)
                {
                    mode = 2; 
                    data = get_here(Camera.px, Camera.py)->data;
                    //uLCD.text_string("C", 4, 4, FONT_7X8, WHITE);
                }
            }    
            else if(mode == 1) //character selected by Player 1
            {
                if (get_here(Camera.px, Camera.py) == NULL || get_here(Camera.px, Camera.py)->type == HEAL || get_here(Camera.px, Camera.py)->type == TRAP)   //check to see whether the space is empty, heal, or trap
                {
                    int tx = ((Player*)data)->x;
                    int ty = ((Player*)data)->y;
                    ((Player*)data)->x = Camera.x;
                    ((Player*)data)->y = Camera.y;
                    
                    if (get_here(Camera.px, Camera.py)->type == HEAL)  //HEAL terrain type heals a character 10 health
                    {
                        ((Player*)data)->hp += 10;
                    }
                    else if (get_here(Camera.px, Camera.py)->type == TRAP) //TRAP terrain type damages a character 10 health 
                    {
                        ((Player*)data)->hp = ((Player*)data)->hp - 10;
                        if (((Player*)data)->hp <= 0)
                        {
                            map_erase(((Player*)data)->x, ((Player*)data)->y);
                            end1 --;
                        }
                        else //if trap doesn't kill character, character can use health potion
                        {
                            if(((Player*)data)->healing > 0) //checks whether character takes damage at least healing capability of health potion and if they have potions and if the character didn't die
                            {
                                ((Player*)data)->hp += 10; 
                                ((Player*)data)->healing --;
                            }
                        }
                    }
                    add_character(Camera.x, Camera.y, ((Player*)data));
                    map_erase(tx, ty);
                    
                    if (get_here(Camera.px+1, Camera.py)->type == ENEMY) //if character is placed adjacent to an enemy
                    {
                        hold = get_here(Camera.px+1,Camera.py)->data;
                        //avoid code
                        if((((Player*)data)->skill - ((Player*)hold)->avoid) >= rand() % 100 + 1)
                        { 
                            ((Player*)hold)->hp -= ((Player*)data)->dmg - ((Player*)hold)->def;
                            if(((Player*)data)->dmg - ((Player*)hold)->def >= 10 && ((Player*)hold)->healing > 0 && ((Player*)hold)->hp > 0) //checks whether character takes damage at least healing capability of health potion and if they have potions and if the character didn't die
                            {
                                ((Player*)hold)->hp += 10; 
                                ((Player*)hold)->healing --;
                            }
                        }
                        if (((Player*)hold)->hp <= 0)  //checks to see if target is alive
                        {
                            map_erase(((Player*)hold)->x, ((Player*)hold)->y);
                            end2 --; 
                        } 
                        else  //other player attacks
                        {
                            if((((Player*)hold)->skill - ((Player*)data)->avoid) >= rand() % 100 + 1) //sees whether a hit or miss
                            {
                                ((Player*)data)->hp -= ((Player*)hold)->dmg - ((Player*)data)->def; 
                                if(((Player*)hold)->dmg - ((Player*)data)->def >= 10 && ((Player*)data)->healing > 0 && ((Player*)data)->hp > 0) //checks whether character takes damage at least healing capability of health potion and if they have potions and if the character didn't die
                                {
                                    ((Player*)data)->hp += 10; 
                                    ((Player*)data)->healing --;
                                }
                                if (((Player*)data)->hp <= 0)
                                {
                                    map_erase(((Player*)data)->x, ((Player*)data)->y);
                                    end1 --;
                                }
                            }
                        }
                    }
                    if (get_here(Camera.px-1, Camera.py)->type == ENEMY) //if character is placed adjacent to an enemy
                    {
                        hold = get_here(Camera.px-1,Camera.py)->data;
                        //avoid code
                        if((((Player*)data)->skill - ((Player*)hold)->avoid) >= rand() % 100 + 1)
                        { 
                            ((Player*)hold)->hp -= ((Player*)data)->dmg - ((Player*)hold)->def;
                            if(((Player*)data)->dmg - ((Player*)hold)->def >= 10 && ((Player*)hold)->healing > 0 && ((Player*)hold)->hp > 0) //checks whether character takes damage at least healing capability of health potion and if they have potions and if the character didn't die
                            {
                                ((Player*)hold)->hp += 10; 
                                ((Player*)hold)->healing --;
                            }
                        }
                        
                        if (((Player*)hold)->hp <= 0)
                        {
                            map_erase(((Player*)hold)->x, ((Player*)hold)->y);
                            end2 --; 
                        } 
                        else
                        {
                            if((((Player*)hold)->skill - ((Player*)data)->avoid) >= rand() % 100 + 1)
                            {
                                ((Player*)data)->hp -= ((Player*)hold)->dmg - ((Player*)data)->def; 
                                if(((Player*)hold)->dmg - ((Player*)data)->def >= 10 && ((Player*)data)->healing > 0 && ((Player*)data)->hp > 0) //checks whether character takes damage at least healing capability of health potion and if they have potions and if the character didn't die
                                {
                                    ((Player*)data)->hp += 10; 
                                    ((Player*)data)->healing --;
                                }
                                if (((Player*)data)->hp <= 0)
                                {
                                    map_erase(((Player*)data)->x, ((Player*)data)->y);
                                    end1 --;
                                }
                            }
                        }
                    }
                    if (get_here(Camera.px, Camera.py + 1)->type == ENEMY)
                    {
                        hold = (get_here(Camera.px, Camera.py + 1))->data;
                        //avoid code
                        if((((Player*)data)->skill - ((Player*)hold)->avoid) >= rand() % 100 + 1)
                        { 
                            ((Player*)hold)->hp -= ((Player*)data)->dmg - ((Player*)hold)->def;
                            if(((Player*)data)->dmg - ((Player*)hold)->def >= 10 && ((Player*)hold)->healing > 0 && ((Player*)hold)->hp > 0) //checks whether character takes damage at least healing capability of health potion and if they have potions and if the character didn't die
                            {
                                ((Player*)hold)->hp += 10; 
                                ((Player*)hold)->healing --;
                            }
                        }
                        if (((Player*)hold)->hp <= 0)
                        {
                            map_erase(((Player*)hold)->x, ((Player*)hold)->y);
                            end2 --; 
                        } 
                        else
                        {
                            if((((Player*)hold)->skill - ((Player*)data)->avoid) >= rand() % 100 + 1)
                            {
                                ((Player*)data)->hp -= ((Player*)hold)->dmg - ((Player*)data)->def; 
                                if(((Player*)hold)->dmg - ((Player*)data)->def >= 10 && ((Player*)data)->healing > 0 && ((Player*)data)->hp > 0) //checks whether character takes damage at least healing capability of health potion and if they have potions and if the character didn't die
                                {
                                    ((Player*)data)->hp += 10; 
                                    ((Player*)data)->healing --;
                                }
                                if (((Player*)data)->hp <= 0)
                                {
                                    map_erase(((Player*)data)->x, ((Player*)data)->y);
                                    end1 --;
                                }
                            }
                        }
                    }
                    if (get_here(Camera.px, Camera.py - 1)->type == ENEMY)
                    {
                        hold = (get_here(Camera.px, Camera.py - 1))->data;
                        //avoid code
                        if((((Player*)data)->skill - ((Player*)hold)->avoid) >= rand() % 100 + 1)
                        { 
                            ((Player*)hold)->hp -= ((Player*)data)->dmg - ((Player*)hold)->def;
                            if(((Player*)data)->dmg - ((Player*)hold)->def >= 10 && ((Player*)hold)->healing > 0 && ((Player*)hold)->hp > 0) //checks whether character takes damage at least healing capability of health potion and if they have potions and if the character didn't die
                            {
                                ((Player*)hold)->hp += 10; 
                                ((Player*)hold)->healing --;
                            }
                        }
                        if (((Player*)hold)->hp <= 0)
                        {
                            map_erase(((Player*)hold)->x, ((Player*)hold)->y);
                            end2 --; 
                        } 
                        else
                        {
                            if((((Player*)hold)->skill - ((Player*)data)->avoid) >= rand() % 100 + 1)
                            {
                                ((Player*)data)->hp -= ((Player*)hold)->dmg - ((Player*)data)->def; 
                                if(((Player*)hold)->dmg - ((Player*)data)->def >= 10 && ((Player*)data)->healing > 0 && ((Player*)data)->hp > 0) //checks whether character takes damage at least healing capability of health potion and if they have potions and if the character didn't die
                                {
                                    ((Player*)data)->hp += 10; 
                                    ((Player*)data)->healing --;
                                }
                                if (((Player*)data)->hp <= 0)
                                {
                                    map_erase(((Player*)data)->x, ((Player*)data)->y);
                                    end1 --;
                                }
                            }
                        }
                    }
                mode = 3;   
                data = NULL;
                hold = NULL;
                speech("Player 1", "Turn Over");         
                }    
            }
            else if(mode == 2) //Player 2 has a character selected
            {
                if (get_here(Camera.px, Camera.py) == NULL || get_here(Camera.px, Camera.py)->type == HEAL || get_here(Camera.px, Camera.py)->type == TRAP) 
                {
                    int tx = ((Player*)data)->x;
                    int ty = ((Player*)data)->y;
                    ((Player*)data)->x = Camera.x;
                    ((Player*)data)->y = Camera.y;
                    
                    if (get_here(Camera.px, Camera.py)->type == HEAL)
                    {
                        ((Player*)data)->hp += 10;
                    }
                    else if (get_here(Camera.px, Camera.py)->type == TRAP)
                    {
                        ((Player*)data)->hp -= 10;
                        if (((Player*)data)->hp <= 0)
                        {
                            map_erase(((Player*)data)->x, ((Player*)data)->y);
                            end2 --;
                        }
                        else 
                        {
                            if(((Player*)data)->healing > 0) //checks whether character takes damage at least healing capability of health potion and if they have potions and if the character didn't die
                            {
                                ((Player*)data)->hp += 10; 
                                ((Player*)data)->healing --;
                            }
                        }
                    } 
                    add_enemy(Camera.x, Camera.y, data);
                    map_erase(tx, ty);
                
                    if (get_here(Camera.px+1, Camera.py)->type == CHARACTERSPRITE)
                    {
                        hold = get_here(Camera.px+1,Camera.py)->data;
                        //avoid code
                        if((((Player*)data)->skill - ((Player*)hold)->avoid) >= rand() % 100 + 1)   //sees if player hits target
                        {
                            ((Player*)hold)->hp -= ((Player*)data)->dmg - ((Player*)hold)->def;
                            if(((Player*)data)->dmg - ((Player*)hold)->def >= 10 && ((Player*)hold)->healing > 0 && ((Player*)hold)->hp > 0) //checks whether character takes damage at least healing capability of health potion and if they have potions and if the character didn't die
                            {
                                ((Player*)hold)->hp += 10; 
                                ((Player*)hold)->healing --;
                            }
                        }
                        if (((Player*)hold)->hp <= 0)  //sees if target is dead
                        {
                            map_erase(((Player*)hold)->x, ((Player*)hold)->y);
                            end1 --;
                        } 
                        else  //if the target is still alive, then other character attacks
                        {
                            if((((Player*)hold)->skill - ((Player*)data)->avoid) >= rand() % 100 + 1)
                            {   
                                ((Player*)data)->hp -= ((Player*)hold)->dmg - ((Player*)data)->def; 
                                if(((Player*)hold)->dmg - ((Player*)data)->def >= 10 && ((Player*)data)->healing > 0 && ((Player*)data)->hp > 0) //checks whether character takes damage at least healing capability of health potion and if they have potions and if the character didn't die
                                {
                                    ((Player*)data)->hp += 10; 
                                    ((Player*)data)->healing --;
                                }
                                if (((Player*)data)->hp <= 0)
                                {
                                    map_erase(((Player*)data)->x, ((Player*)data)->y);
                                    end2 --;
                                }
                            }
                        }
                    }
                    if (get_here(Camera.px-1, Camera.py)->type == CHARACTERSPRITE)
                    {
                        hold = get_here(Camera.px-1,Camera.py)->data;
                        //avoid code
                        if((((Player*)data)->skill - ((Player*)hold)->avoid) >= rand() % 100 + 1)   //sees if player hits target
                        {
                            ((Player*)hold)->hp -= ((Player*)data)->dmg - ((Player*)hold)->def;
                            if(((Player*)data)->dmg - ((Player*)hold)->def >= 10 && ((Player*)hold)->healing > 0 && ((Player*)hold)->hp > 0) //checks whether character takes damage at least healing capability of health potion and if they have potions and if the character didn't die
                            {
                                ((Player*)hold)->hp += 10; 
                                ((Player*)hold)->healing --;
                            }
                        }
                        if (((Player*)hold)->hp <= 0)  //sees if target is dead
                        {
                            map_erase(((Player*)hold)->x, ((Player*)hold)->y);
                            end1 --;
                        } 
                        else  //if the target is still alive, then other character attacks
                        {
                            if((((Player*)hold)->skill - ((Player*)data)->avoid) >= rand() % 100 + 1)
                            {   
                                ((Player*)data)->hp -= ((Player*)hold)->dmg - ((Player*)data)->def; 
                                if(((Player*)hold)->dmg - ((Player*)data)->def >= 10 && ((Player*)data)->healing > 0 && ((Player*)data)->hp > 0) //checks whether character takes damage at least healing capability of health potion and if they have potions and if the character didn't die
                                {
                                    ((Player*)data)->hp += 10; 
                                    ((Player*)data)->healing --;
                                }
                                if (((Player*)data)->hp <= 0)
                                {
                                    map_erase(((Player*)data)->x, ((Player*)data)->y);
                                    end2 --;
                                }
                            }
                        }
                    }
                    if (get_here(Camera.px, Camera.py + 1)->type == CHARACTERSPRITE)
                    {
                        hold = (get_here(Camera.px, Camera.py + 1))->data;
                        //avoid code
                        if((((Player*)data)->skill - ((Player*)hold)->avoid) >= rand() % 100 + 1)   //sees if player hits target
                        {
                            ((Player*)hold)->hp -= ((Player*)data)->dmg - ((Player*)hold)->def;
                            if(((Player*)data)->dmg - ((Player*)hold)->def >= 10 && ((Player*)hold)->healing > 0 && ((Player*)hold)->hp > 0) //checks whether character takes damage at least healing capability of health potion and if they have potions and if the character didn't die
                            {
                                ((Player*)hold)->hp += 10; 
                                ((Player*)hold)->healing --;
                            }
                        }
                        if (((Player*)hold)->hp <= 0)  //sees if target is dead
                        {
                            map_erase(((Player*)hold)->x, ((Player*)hold)->y);
                            end1 --;
                        } 
                        else  //if the target is still alive, then other character attacks
                        {
                            if((((Player*)hold)->skill - ((Player*)data)->avoid) >= rand() % 100 + 1)
                            {   
                                ((Player*)data)->hp -= ((Player*)hold)->dmg - ((Player*)data)->def; 
                                if(((Player*)hold)->dmg - ((Player*)data)->def >= 10 && ((Player*)data)->healing > 0 && ((Player*)data)->hp > 0) //checks whether character takes damage at least healing capability of health potion and if they have potions and if the character didn't die
                                {
                                    ((Player*)data)->hp += 10; 
                                    ((Player*)data)->healing --;
                                }
                                if (((Player*)data)->hp <= 0)
                                {
                                    map_erase(((Player*)data)->x, ((Player*)data)->y);
                                    end2 --;
                                }
                            }
                        }
                    }
                    if (get_here(Camera.px, Camera.py - 1)->type == CHARACTERSPRITE)
                    {
                        hold = (get_here(Camera.px, Camera.py - 1))->data;
                        //avoid code
                        if((((Player*)data)->skill - ((Player*)hold)->avoid) >= rand() % 100 + 1)   //sees if player hits target
                        {
                            ((Player*)hold)->hp -= ((Player*)data)->dmg - ((Player*)hold)->def;
                            if(((Player*)data)->dmg - ((Player*)hold)->def >= 10 && ((Player*)hold)->healing > 0 && ((Player*)hold)->hp > 0) //checks whether character takes damage at least healing capability of health potion and if they have potions and if the character didn't die
                            {
                                ((Player*)hold)->hp += 10; 
                                ((Player*)hold)->healing --;
                            }
                        }
                        if (((Player*)hold)->hp <= 0)  //sees if target is dead
                        {
                            map_erase(((Player*)hold)->x, ((Player*)hold)->y);
                            end1 --;
                        } 
                        else  //if the target is still alive, then other character attacks
                        {
                            if((((Player*)hold)->skill - ((Player*)data)->avoid) >= rand() % 100 + 1)
                            {   
                                ((Player*)data)->hp -= ((Player*)hold)->dmg - ((Player*)data)->def; 
                                if(((Player*)hold)->dmg - ((Player*)data)->def >= 10 && ((Player*)data)->healing > 0 && ((Player*)data)->hp > 0) //checks whether character takes damage at least healing capability of health potion and if they have potions and if the character didn't die
                                {
                                    ((Player*)data)->hp += 10; 
                                    ((Player*)data)->healing --;
                                }
                                if (((Player*)data)->hp <= 0)
                                {
                                    map_erase(((Player*)data)->x, ((Player*)data)->y);
                                    end2 --;
                                }
                            }
                        }
                    }
                    mode = 0; //goes to Player 1's turn
                    data = NULL;
                    hold = NULL;
                    speech("Player 2", "Turn Over");               
                }
            }
        break;   
            
        case BACK_BUTTON:  
            if(mode == 1){  //returns to free mode for Player 1
                mode = 0;
                data = NULL; 
            }
            else if(mode == 2){ //returns to free mode for  Player 2
                mode = 3;
                data = NULL;
            }
            else if(mode == 0){  //ends Player 1's turn
                mode = 3;
                data = NULL;
                speech("Player 1", "Turn Over");
                }
            else if(mode == 3){   //ends Player 2's turn
                mode = 0;
                data = NULL;
                speech("Player 2", "Turn Over");
                }
            break;
        
        case DISPLAY_BUTTON:
            if(mode == 1 || mode == 2){
                uLCD.filled_rectangle(0, 0, 127, 127, BLACK);
                uLCD.printf("\nCharacter stats:\nhealth: %i \nattack: %i \ndefence: %i \nrange: %i \nskill: %i \navoid: %i \n\nCharacter items: \nHealth Potions:%i\n\n\n\n\n\n",((Player*)data)->hp, ((Player*)data)->dmg, ((Player*)data)->def, ((Player*)data)->range, ((Player*)data)->skill, ((Player*)data)->avoid, ((Player*)data)->healing);
                wait(5);
                uLCD.filled_rectangle(0, 0, 127, 127, BLACK);
                
            }
            break;
                
            
        case GO_UP:
            if(mode == 0 || mode == 3){   //during free mode for both Player's the cursor can go anywhere within the map
                if(get_north(Camera.px, Camera.py)->type != WALL){
                    Camera.y = Camera.y - 1;
                }      
            }
            else if(mode == 1 || mode == 2){
                if (get_north(Camera.px, Camera.py) == NULL || get_north(Camera.px, Camera.py)->type == HEAL || get_north(Camera.px, Camera.py)->type == TRAP)
                {
                    if((Camera.y-1 >= ((Player*)data)->y - ((Player*)data)->range)){
                        Camera.y = Camera.y - 1;
                    }
                }
            }
            break;  
        case GO_LEFT:
            if(mode == 0 || mode == 3){
                if(get_west(Camera.px, Camera.py)->type != WALL){
                    Camera.x = Camera.x + 1;
                }      
            }
            else if(mode == 1 || mode ==2){
                if (get_west(Camera.px, Camera.py) == NULL || get_west(Camera.px, Camera.py)->type == HEAL || get_west(Camera.px, Camera.py)->type == TRAP)
                {
                    if(Camera.x+1 <= (((Player*)data)->x + ((Player*)data)->range)){
                        Camera.x = Camera.x + 1;
                    }
                }
            }
            break;
        case GO_DOWN:
            if(mode == 0 || mode == 3){
                if(get_south(Camera.px, Camera.py)->type != WALL){
                    Camera.y = Camera.y + 1;
                }      
            }
            else if(mode == 1 || mode == 2){
                if (get_south(Camera.px, Camera.py) == NULL || get_south(Camera.px, Camera.py)->type == HEAL || get_south(Camera.px, Camera.py)->type == TRAP)
                {
                    if(Camera.y+1 <= (((Player*)data)->y + ((Player*)data)->range)){
                        Camera.y = Camera.y + 1;
                    }
                }
            }
            break;
        case GO_RIGHT:
            if(mode == 0 || mode == 3){
                if(get_east(Camera.px, Camera.py)->type != WALL){
                    Camera.x = Camera.x - 1;
                }      
            }
            else if(mode == 1 || mode == 2){
                if (get_east(Camera.px, Camera.py) == NULL || get_east(Camera.px, Camera.py)->type == HEAL || get_east(Camera.px, Camera.py)->type == TRAP)
                {
                    if(Camera.x-1 >= (((Player*)data)->x - ((Player*)data)->range)){
                        Camera.x = Camera.x - 1;
                    }
                }
            }
            break;
            
        default:
            break;        
    }
    return NO_RESULT;
}

/**
 * Entry point for frame drawing. This should be called once per iteration of
 * the game loop. This draws all tiles on the screen, followed by the status
 * bars. Unless init is nonzero, this function will optimize drawing by only
 * drawing tiles that have changed from the previous frame.
 */
void draw_game(int init)
{
    // Draw game border first
    if(init) draw_border();

    // Iterate over all visible map tiles
    for (int i = -5; i <= 5; i++) { // Iterate over columns of tiles
        for (int j = -4; j <= 4; j++) { // Iterate over one column of tiles
            // Here, we have a given (i,j)

            // Compute the current map (x,y) of this tile
            int x = i + Camera.x;
            int y = j + Camera.y;

            // Compute the previous map (px, py) of this tile
            int px = i + Camera.px;
            int py = j + Camera.py;

            // Compute u,v coordinates for drawing
            int u = (i+5)*11 + 3;
            int v = (j+4)*11 + 15;

            // Figure out what to draw
            DrawFunc draw = NULL;
            if (i == 0 && j == 0) {
                // Decide what to draw at the 0 position
                draw = draw_selection;
            } 
            else if (x >= 0 && y >= 0 && x < map_width() && y < map_height()) { // Current (i,j) in the map
                MapItem* curr_item = get_here(x, y);
                MapItem* prev_item = get_here(px, py);
                if (init || curr_item != prev_item) { // Only draw if they're different
                    if (curr_item) { // There's something here! Draw it
                        draw = curr_item->draw;
                    } 
                    else { // There used to be something, but now there isn't
                        draw = draw_nothing;
                    }
                }
            } else if (init) { // If doing a full draw, but we're out of bounds, draw the walls.
                draw = draw_wall;
            }
            // Actually draw the tile
            if (draw) draw(u, v);
        }
    }

    // Draw status bars
    draw_upper_status();
    draw_lower_status();
}

/**
 * Initialize the main world map. Add walls around the edges, interior chambers,
 * and plants in the background so you can see motion.
 */
void init_main_map()
{
    // "Random" plants
    Map* map = set_active_map(0);
    for(int i = map_width() + 3; i < map_area(); i += 39) {
        add_plant(i % map_width(), i / map_width());
    }
    pc.printf("plants\r\n");
    
    for(int i = map_width() + 5; i < map_area(); i += 133) {
        add_trap(i % map_width(), i / map_width());
    }
    
    for(int i = map_width() + 7; i < map_area(); i += 217) {
        add_heal(i % map_width(), i / map_width());
    }

    pc.printf("Adding walls!\r\n");
    add_wall(0,              0,              HORIZONTAL, map_width());
    add_wall(0,              map_height()-1, HORIZONTAL, map_width());
    add_wall(0,              0,              VERTICAL,   map_height());
    add_wall(map_width()-1,  0,              VERTICAL,   map_height());
    pc.printf("Walls done!\r\n");

    add_character(char1.x, char1.y, &char1);
    add_character(char2.x, char2.y, &char2);
    add_character(char3.x, char3.y, &char3);
    add_enemy(enemy1.x, enemy1.y, &enemy1);
    add_enemy(enemy2.x, enemy2.y, &enemy2);
    add_enemy(enemy3.x, enemy3.y, &enemy3);

    print_map();
}


/**
 * Program entry point! This is where it all begins.
 * This function orchestrates all the parts of the game. Most of your
 * implementation should be elsewhere - this holds the game loop, and should
 * read like a road map for the rest of the code.
 */
int main()
{
    // First things first: initialize hardware
    ASSERT_P(hardware_init() == ERROR_NONE, "Hardware init failed!");
    
    pc.printf("Program Starting");
    uLCD.text_string("Welcome to \nthe game: \nPlayer 1\nPlayer2", 4, 4, FONT_7X8, BLUE); //creats start screen
    wait(3);
    uLCD.filled_rectangle(0, 0, 127, 127, BLACK);
    uLCD.text_string("The two of you \nwill take turns \nmoving your \ncharacters.\nFirst one to \ndefeat all \nenemy characters \nwins!", 0, 4, FONT_7X8, BLUE);
    wait(5);
    uLCD.filled_rectangle(0, 0, 127, 127, BLACK);
    uLCD.text_string("Press button 1 \nto select\nbutton 2 to go \nback or end turn\nbutton 3 for \ncharacter info\nand see \ncharacter items.\nThe avoid skill is \nimplemented in \nthe game.", 0, 1, FONT_7X8, BLUE);
    wait(10);
    uLCD.filled_rectangle(0, 0, 127, 127, BLACK);
    uLCD.text_string("Characters also \nhave automatic \nhealing items. \nHealing (white)\nand Trap(orange) \nterrain types \n are included!", 0, 4, FONT_7X8, BLUE);
    wait(5);
    // Initialize the maps
    maps_init();
    init_main_map();
    
    Camera.x = Camera.px = 3;
    Camera.y = Camera.px = 3;
    
    
    // Initialize game state
    set_active_map(0);

    // Initial drawing
    draw_game(true);

    // Main game loop
    while(1) {
        // Timer to measure game update speed
        Timer t;
        t.start();

        // 1. Read inputs
        GameInputs in = read_inputs();

        // 2. Determine action (move, act, menu, etc.)
        int action = get_action(in);
        // 3. Update game
        int update = update_game(action);
        // 3b. Check for game over
        if(end1 == 0){
            uLCD.filled_rectangle(0, 0, 127, 127, BLACK);
            uLCD.text_string("Player 2 \nWins!!!", 4, 4, FONT_7X8, GREEN);
            wait(3);
            break;
        }
        else if(end2 == 0){
            uLCD.filled_rectangle(0, 0, 127, 127, BLACK);
            uLCD.text_string("GAME OVER:\nPlayer 1 \nWins!!!", 4, 4, FONT_7X8, RED);
            wait(3);
            break;
        }
        // 4. Draw screen
        draw_game(update); 

        // Compute update time
        t.stop();
        int dt = t.read_ms();
        if (dt < 100) wait_ms(100 - dt);
    }
}

