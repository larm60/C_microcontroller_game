#include "speech.h"

#include "globals.h"
#include "hardware.h"

/**
 * Draw the speech bubble background.
 */
static void draw_speech_bubble();

/**
 * Erase the speech bubble.
 */
static void erase_speech_bubble();

/**
 * Draw a single line of the speech bubble.
 * @param line The text to display
 * @param which If TOP, the first line; if BOTTOM, the second line.
 */
#define TOP    0
#define BOTTOM 1
static void draw_speech_line(const char* line, int which);

/**
 * Delay until it is time to scroll.
 */
static void speech_bubble_wait();

void draw_speech_bubble()
{
    uLCD.filled_rectangle(3, 96, 123, 115, 0xCDDC39);
}

void erase_speech_bubble()
{
    uLCD.filled_rectangle(3, 96, 123, 115, BLACK);
}

void draw_speech_line(const char* line, int which)
{
    uLCD.locate(1,12 + which);
    uLCD.textbackground_color(0xCDDC39);
    uLCD.printf(line);
}

void speech_bubble_wait()
{
    GameInputs inputs;
    inputs = read_inputs();
    
    
    Timer t; t.start();
    int count1 = 0;
    int count2 = 0;
    const int ANIMATION_FRAMES = 5;
    do
    { 
        t.stop();
        int dt = t.read_ms();
        if (dt < 100) wait_ms(100 - dt);
        
        if (count2 && count1 < ANIMATION_FRAMES) //The blinker
        {
            uLCD.filled_rectangle(118,108,122,112,BLACK);
            count1++;
            if (count1 == ANIMATION_FRAMES) { count1 = 0; count2--; }
        }
        else
        {
            uLCD.filled_rectangle(118,108,122,112,WHITE);
            count1++;
            if (count1 == ANIMATION_FRAMES) { count1 = 0; count2++; }
        }
        inputs = read_inputs();
    } while (inputs.b1);
}

void speech(const char* line1, const char* line2)
{
    draw_speech_bubble();
    draw_speech_line(line1, TOP);
    draw_speech_line(line2, BOTTOM);
    speech_bubble_wait();
    erase_speech_bubble();
}

void long_speech(const char* lines[], int n)
{
}
